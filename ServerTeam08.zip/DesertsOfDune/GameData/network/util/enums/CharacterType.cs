﻿namespace GameData.network.messages
{
    /// <summary>
    /// This enum descibes the different types of characters.
    /// </summary>
    public enum CharacterType
    {
        NOBLE,
        MENTAT,
        BENEGESSERIT,
        FIGHTER
    }
}
