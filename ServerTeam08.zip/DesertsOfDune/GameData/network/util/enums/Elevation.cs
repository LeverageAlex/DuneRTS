﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GameData.network.util.enums
{
    /// <summary>
    /// This enum represents the hight levels of MapFields
    /// </summary>
    public enum Elevation
    {
        high, low
    }
}
