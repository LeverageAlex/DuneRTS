﻿using System;
namespace Server
{
    public class ReplaySpectator
    {
        private string _clientName;

        public ReplaySpectator(string clientName)
        {
            _clientName = clientName;
        }
    }
}
