﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;

namespace UnitTestSuite.serverTest.roundHandlerTest
{
    /// <summary>
    /// This Class is used to Test the class SandwormPhase
    /// </summary>
    public class TestSandwormPhase
    {
        [SetUp]
        public void Setup()
        {
        }

    }
}
