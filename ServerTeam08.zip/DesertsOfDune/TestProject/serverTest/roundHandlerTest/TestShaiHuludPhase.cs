﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;

namespace UnitTestSuite.serverTest.roundHandlerTest
{
    /// <summary>
    /// This Class is used to Test the class ShaiHuludPhase
    /// </summary>
    public class TestShaiHuludPhase
    {
        [SetUp]
        public void Setup()
        {
        }

        /// <summary>
        /// This Testcase validates the behaviour of the method ChooseTargetCharacter
        /// </summary>
        [Test]
        public void TestChooseTargetCharacter()
        {
            // implement logic
        }

        /// <summary>
        /// This Testcase validates the behaviour of the method EatTargetCharacter
        /// </summary>
        [Test]
        public void TestEatTargetCharacter()
        {
            // implement logic
        }
    }
}
