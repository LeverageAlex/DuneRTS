﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;

namespace UnitTestSuite.serverTest.roundHandlerTest
{
    /// <summary>
    /// This Class is used to Test the class SandstormPhase
    /// </summary>
    public class TestSandstormPhase
    {

        [SetUp]
        public void Setup()
        {
        }

        /// <summary>
        /// This Testcase validates the behaviour of the method RandomWalk
        /// </summary>
        [Test]
        public void TestRandomWalk()
        {
            // implement logic
        }

        /// <summary>
        /// This Testcase validates the behaviour of the method CalculateNewStrom
        /// </summary>
        [Test]
        public void TestCalculateNewStrom()
        {
            // implement logic
        }
    }
}
