﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;

namespace UnitTestSuite.serverTest
{
    class ServerMessageControllerTest
    {

        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void OnActionRequestMessageTest()
        {
            /*string action = "ATTACK";
            switch (Enum.Parse(typeof(ActionType), action))
            {
                case ActionType.ATTACK:
                    actionCharacter.Atack(targetCharacter);
                    Console.WriteLine("Test");
                    break;

                case ActionType.COLLECT:
                    actionCharacter.CollectSpice();
                    break;
            }*/
        }
    }
}
