public enum CharTypeEnum
{
    NOBLE, MENTANT, BENEGESSERIT, FIGHTER
}
